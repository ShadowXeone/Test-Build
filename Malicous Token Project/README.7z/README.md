# Kekius Token Risk Scanner

A lightweight web widget to scan Ethereum-style token addresses and fetch live risk scores using the Scam Tracker API.

## Usage

Clone this repository and open `index.html` in your browser.

## Setup

- Customize `apiBase` in `app.js` with your endpoint.
- Style and expand results UI if needed.

## License

MIT — Powered by the Kekius Security Suite
